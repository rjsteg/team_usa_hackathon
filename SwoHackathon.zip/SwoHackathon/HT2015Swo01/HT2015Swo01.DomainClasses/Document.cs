﻿using System;
using HT2015Swo01.DomainClasses.Enums;

namespace HT2015Swo01.DomainClasses
{
    public class Document
    {
        public int Id { get; set; }

        public DocumentType Type { get; set; }
        public string Name { get; set; }
        public DateTime CreatedDate { get; set; }
        public string Content { get; set; }
    }
}
