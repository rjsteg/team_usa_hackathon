﻿using System;
using System.Collections.Generic;
using HT2015Swo01.DomainClasses.Enums;

namespace HT2015Swo01.DomainClasses
{
    public class Employee
    {
        public int Id { get; set; }
        public string Email { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime HireDate { get; set; }

        public ConsultantGrade ConsultantGrade { get; set; }
        public Practice Practice { get; set; }
        public bool PracticeManager { get; set; }

        public int? CounselorId { get; set; }

        public ICollection<Document> Documents { get; set; }
        public ICollection<Message> Messages { get; set; }
        public ICollection<Engagement> Engagements { get; set; }
    }
}