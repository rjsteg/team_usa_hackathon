﻿using System;

namespace HT2015Swo01.DomainClasses
{
    public class Message
    {
        public int Id { get; set; }
 
        public string Body { get; set; }
        public DateTime MessageSent { get; set; }
        public bool Read { get; set; }

        public int EmployeeId { get; set; }
        public int CounselorId { get; set; }
        public int SenderId { get; set; }

        //employeeId who received the message
        public int RecepientId { get; set; }
        //relationship between this message and another message
        public int? ParentId { get; set; }
    }
}
