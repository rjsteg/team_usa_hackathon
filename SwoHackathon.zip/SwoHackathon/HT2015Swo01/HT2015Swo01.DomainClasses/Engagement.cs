﻿using System;

namespace HT2015Swo01.DomainClasses
{
    public class Engagement
    {
        public int Id { get; set; }

        public string ClientName { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public string Description { get; set; }
        public int EngagementLevel { get; set; }
        public bool AtTheOffice { get; set; }
    }
}