﻿using System.ComponentModel.DataAnnotations;

namespace HT2015Swo01.DomainClasses.Enums
{
    public enum Practice
    {
        [Display(Name= "Software Development & Integration")]
        SoftwareDevelopmentAndIntegration,
        [Display(Name = "Testing")]
        Testing,
        [Display(Name = "BusinessIntelligenceAndAnalystics")]
        BusinessIntelligenceAndAnalystics,
        [Display(Name = "Product Lifecycle Management")]
        ProductLifecycleManagement,
        [Display(Name = "Digital Transformation")]
        DigitalTransformation,
        [Display(Name = "Cloud")]
        Cloud
    }
}
