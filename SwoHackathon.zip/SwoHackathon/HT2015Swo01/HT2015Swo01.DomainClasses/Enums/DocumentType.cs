﻿using System.ComponentModel.DataAnnotations;

namespace HT2015Swo01.DomainClasses.Enums
{
    public enum DocumentType
    {
        [Display(Name = "Status Report")]
        StatusReport,
        [Display(Name = "Resume")]
        Resume,
        [Display(Name = "Certification")]
        Certification
    }
}
