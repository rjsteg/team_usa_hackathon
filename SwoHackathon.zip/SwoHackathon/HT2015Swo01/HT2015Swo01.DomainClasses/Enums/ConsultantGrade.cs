﻿using System.ComponentModel.DataAnnotations;

namespace HT2015Swo01.DomainClasses.Enums
{
    public enum ConsultantGrade
    {
        [Display(Name = "A1 (Associate Consultant)")]
        A1,
        [Display(Name = "A2 (Consultant)")]
        A2,
        [Display(Name = "B (Senior Consultant)")]
        B,
        [Display(Name = "C (Manager)")]
        C,
        [Display(Name = "D1 (Senior Manager)")]
        D1,
        [Display(Name = "D2 (Director)")]
        D2,
        [Display(Name = "E (Associate Vice President)")]
        E,
        [Display(Name = "F (Vice President)")]
        F
    }
}
