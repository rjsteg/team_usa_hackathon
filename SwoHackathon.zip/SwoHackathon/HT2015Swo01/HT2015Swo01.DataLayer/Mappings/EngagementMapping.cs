﻿using HT2015Swo01.DomainClasses;
using System.Data.Entity.ModelConfiguration;

namespace HT2015Swo01.DataLayer.Mappings
{
    public class EngagementMapping : EntityTypeConfiguration<Engagement>
    {
        public EngagementMapping()
        {
            Property(t => t.ClientName).HasMaxLength(256).IsRequired();
            Property(t => t.Description).IsMaxLength().IsRequired();
            Property(t => t.StartDate).IsRequired();
            Property(t => t.EndDate).IsOptional();
            Property(t => t.EngagementLevel).IsOptional();
            Property(t => t.AtTheOffice).IsRequired();
        }
    }
}
