﻿using HT2015Swo01.DomainClasses;
using System.Data.Entity.ModelConfiguration;

namespace HT2015Swo01.DataLayer.Mappings
{
    public class EmployeeMapping : EntityTypeConfiguration<Employee>
    {
        public EmployeeMapping()
        {
            Property(t => t.Email).HasMaxLength(256).IsRequired();
            Property(t => t.FirstName).HasMaxLength(35).IsRequired();
            Property(t => t.LastName).HasMaxLength(35).IsRequired();
            Property(t => t.HireDate).IsRequired();

            //makes FK column employee_id in tables Document, Engagement and Message not null
            HasMany(r => r.Documents).WithRequired().WillCascadeOnDelete(true);
            HasMany(r => r.Engagements).WithRequired().WillCascadeOnDelete(true);
            HasMany(r => r.Messages).WithRequired().WillCascadeOnDelete(true);

        }
    }
}
