﻿using HT2015Swo01.DomainClasses;
using System.Data.Entity.ModelConfiguration;

namespace HT2015Swo01.DataLayer.Mappings
{
    public class DocumentMapping : EntityTypeConfiguration<Document>
    {
        public DocumentMapping()
        {
            Property(t => t.Name).HasMaxLength(256).IsRequired();
            Property(t => t.Content).IsMaxLength().IsRequired();
            Property(t => t.CreatedDate).IsRequired();
            Property(t => t.Type).IsRequired();
        }
    }
}