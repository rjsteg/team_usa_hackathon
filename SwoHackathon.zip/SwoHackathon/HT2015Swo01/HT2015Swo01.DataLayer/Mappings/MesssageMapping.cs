﻿using HT2015Swo01.DomainClasses;
using System.Data.Entity.ModelConfiguration;

namespace HT2015Swo01.DataLayer.Mappings
{
    public class MessageMapping : EntityTypeConfiguration<Message>
    {
        public MessageMapping()
        {
            Property(t => t.Body).IsMaxLength().IsRequired();
            Property(t => t.MessageSent).IsRequired();
            Property(t => t.Read).IsRequired();
            Property(t => t.RecepientId).IsRequired();
            Property(t => t.ParentId).IsOptional();

            Property(t => t.EmployeeId).IsRequired();
            Property(t => t.CounselorId).IsRequired();
            Property(t => t.SenderId).IsRequired();
        }
    }
}
