﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Migrations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HT2015Swo01.DomainClasses;

namespace HT2015Swo01.DataLayer.Migrations
{
    public static class EmployeeData
    {
        public static void AddData(CounselorContext db)
        {
            var employees = new List<Employee>
            {
            new Employee
            {
                Email = "urban.meyer@osu.org",
                FirstName = "Urban",
                LastName = "Meyer",
                HireDate = new System.DateTime(2011,11,29),
                ConsultantGrade = DomainClasses.Enums.ConsultantGrade.E,
                Practice = DomainClasses.Enums.Practice.SoftwareDevelopmentAndIntegration,
                PracticeManager = true,
                Documents = new List<Document>
                {
                    new Document
                    {
                        Type = DomainClasses.Enums.DocumentType.StatusReport,
                        Name = "Michigan State",
                        CreatedDate = new System.DateTime(2015,11,22),
                        Content = "lost 17-14, no offense",
                    },
                    new Document
                    {
                        Type = DomainClasses.Enums.DocumentType.Resume,
                        Name = "National Champions 2014",
                        CreatedDate = new System.DateTime(2015,1,12),
                        Content = "Crushed Oregon 42 - 20"
                    }
                },
                Engagements = new List<Engagement>
                {
                    new Engagement
                    {
                        ClientName = "Ohio State",
                        StartDate =  new System.DateTime(2011,11,29),
                        Description = "Head coach of football team",
                        EngagementLevel = 4,
                        AtTheOffice =false
                    }
                }
            },
            new Employee
            {
                Email = "jt.barrett@osu.org",
                FirstName = "JT",
                LastName = "Barrett",
                HireDate = new System.DateTime(2013,9,1),
                ConsultantGrade = DomainClasses.Enums.ConsultantGrade.B,
                Practice = DomainClasses.Enums.Practice.SoftwareDevelopmentAndIntegration,
                PracticeManager = false,
                CounselorId =1
            },
            new Employee
            {
                Email = "ryan.echternacht@osu.org",
                FirstName = "ryan",
                LastName = "echternacht",
                HireDate = new System.DateTime(2013,9,1),
                ConsultantGrade = DomainClasses.Enums.ConsultantGrade.A2,
                Practice = DomainClasses.Enums.Practice.SoftwareDevelopmentAndIntegration,
                PracticeManager = false,
                CounselorId = 1,
                Documents = new List<Document>
                {
                    new Document
                    {
                        Type = DomainClasses.Enums.DocumentType.Resume,
                        Name = "Michigan State",
                        CreatedDate = new System.DateTime(2015,11,22),
                        Content = Resumes.Ryan
                    }
                },
            },
            new Employee
            {
                Email = "bennie.thompson@osu.org",
                FirstName = "bennie",
                LastName = "thompson",
                HireDate = new System.DateTime(2013,9,1),
                ConsultantGrade = DomainClasses.Enums.ConsultantGrade.A2,
                Practice = DomainClasses.Enums.Practice.DigitalTransformation,
                PracticeManager = false,
                CounselorId = 1,
                Documents = new List<Document>
                {
                    new Document
                    {
                        Type = DomainClasses.Enums.DocumentType.Resume,
                        Name = "Michigan State",
                        CreatedDate = new System.DateTime(2015,11,22),
                        Content = Resumes.Bennie
                    }
                }
            },
            new Employee
            {
                Email = "pm@us.sogeti.com",
                FirstName = "Carl",
                LastName = "Doe",
                HireDate = new System.DateTime(2000,2,28),
                ConsultantGrade = DomainClasses.Enums.ConsultantGrade.D2,
                Practice = DomainClasses.Enums.Practice.Testing,
                PracticeManager = true,
                Documents = new List<Document>
                {
                    new Document
                    {
                        Type = DomainClasses.Enums.DocumentType.Resume,
                        Name = "current resume",
                        CreatedDate = new System.DateTime(2015,11,22),
                        Content = Resumes.Carl
                    }
                }
            },
            new Employee
            {
                Email = "counselor@us.sogeti.com",
                FirstName = "Travis",
                LastName = "Tritt",
                HireDate = new System.DateTime(2001,6,1),
                ConsultantGrade = DomainClasses.Enums.ConsultantGrade.C,
                Practice = DomainClasses.Enums.Practice.Testing,
                PracticeManager = false,
                CounselorId = 5,
                Documents = new List<Document>
                {
                    new Document
                    {
                        Type = DomainClasses.Enums.DocumentType.Resume,
                        Name = "current resume",
                        CreatedDate = new System.DateTime(2015,6,22),
                        Content = Resumes.Travis
                    }
                }
            },
            new Employee
            {
                Email = "counselee@us.sogeti.com",
                FirstName = "Stacey",
                LastName = "Jones",
                HireDate = new System.DateTime(2014,9,1),
                ConsultantGrade = DomainClasses.Enums.ConsultantGrade.A1,
                Practice = DomainClasses.Enums.Practice.Testing,
                PracticeManager = false,
                CounselorId = 6,
                Documents = new List<Document>
                {
                    new Document
                    {
                        Type = DomainClasses.Enums.DocumentType.Resume,
                        Name = "current resume",
                        CreatedDate = new System.DateTime(2015,3,12),
                        Content = Resumes.Stacey
                    }
                }
            },
            new Employee
            {
                Email = "Leroy.Anderson@us.sogeti.com",
                FirstName = "Leroy",
                LastName = "Anderson",
                HireDate = new System.DateTime(2015,9,1),
                ConsultantGrade = DomainClasses.Enums.ConsultantGrade.A1,
                Practice = DomainClasses.Enums.Practice.Testing,
                PracticeManager = false,
                CounselorId = 6,
                Documents = new List<Document>
                {
                    new Document
                    {
                        Type = DomainClasses.Enums.DocumentType.Resume,
                        Name = "current resume",
                        CreatedDate = new System.DateTime(2015,9,2),
                        Content = Resumes.Leroy
                    }
                }
            },
            new Employee
            {
                Email = "bob.cat@us.sogeti.com",
                FirstName = "Bob",
                LastName = "Cat",
                HireDate = new System.DateTime(2006,7,5),
                ConsultantGrade = DomainClasses.Enums.ConsultantGrade.C,
                Practice = DomainClasses.Enums.Practice.SoftwareDevelopmentAndIntegration,
                PracticeManager = false,
                CounselorId = 1,
                Documents = new List<Document>
                {
                    new Document
                    {
                        Type = DomainClasses.Enums.DocumentType.Resume,
                        Name = "current resume",
                        CreatedDate = new System.DateTime(2015,6,30),
                        Content = Resumes.Bob
                    }
                }
            },
       };
        db.Employees.AddOrUpdate(e => e.Email, employees.ToArray());

        db.Employees.AddRange(employees);

        var employee = employees[0];
        employee.Messages = new List<Message>
        {
            new Message
            {
                Body = "Did you get pulled over last night?",
                MessageSent = new System.DateTime(2015,10,31,9,3,2),
                Read = true,
                RecepientId = 1,
                SenderId = 1
            }
        };
            db.Employees.AddOrUpdate(e => e.FirstName, employee);
            employee = employees[1];
            employee.Messages = new List<Message>
        {
            new Message
            {
                Body = "Yes, Cardale Jones bailed me out. Sorry coach.",
                MessageSent = new System.DateTime(2015,10,31,9,47,21),
                Read = false,
                RecepientId = 1,
                ParentId =1,
                SenderId = 2
            }
        };
            db.Employees.AddOrUpdate(e => e.FirstName, employee);
        }

    }
}
