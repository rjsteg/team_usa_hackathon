namespace HT2015Swo01.DataLayer.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class InitialCreate : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Documents",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Type = c.Int(nullable: false),
                        Name = c.String(nullable: false, maxLength: 256),
                        CreatedDate = c.DateTime(nullable: false),
                        Content = c.String(nullable: false),
                        Employee_Id = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Employees", t => t.Employee_Id, cascadeDelete: true)
                .Index(t => t.Employee_Id);
            
            CreateTable(
                "dbo.Employees",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Email = c.String(nullable: false, maxLength: 256),
                        FirstName = c.String(nullable: false, maxLength: 35),
                        LastName = c.String(nullable: false, maxLength: 35),
                        HireDate = c.DateTime(nullable: false),
                        ConsultantGrade = c.Int(nullable: false),
                        Practice = c.Int(nullable: false),
                        PracticeManager = c.Boolean(nullable: false),
                        CounselorId = c.Int(),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.Engagements",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        ClientName = c.String(nullable: false, maxLength: 256),
                        StartDate = c.DateTime(nullable: false),
                        EndDate = c.DateTime(),
                        Description = c.String(nullable: false),
                        EngagementLevel = c.Int(),
                        AtTheOffice = c.Boolean(nullable: false),
                        Employee_Id = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Employees", t => t.Employee_Id, cascadeDelete: true)
                .Index(t => t.Employee_Id);
            
            CreateTable(
                "dbo.Messages",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Body = c.String(nullable: false),
                        MessageSent = c.DateTime(nullable: false),
                        Read = c.Boolean(nullable: false),
                        EmployeeId = c.Int(nullable: false),
                        CounselorId = c.Int(nullable: false),
                        SenderId = c.Int(nullable: false),
                        RecepientId = c.Int(nullable: false),
                        ParentId = c.Int(),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Employees", t => t.EmployeeId, cascadeDelete: true)
                .Index(t => t.EmployeeId);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Messages", "EmployeeId", "dbo.Employees");
            DropForeignKey("dbo.Engagements", "Employee_Id", "dbo.Employees");
            DropForeignKey("dbo.Documents", "Employee_Id", "dbo.Employees");
            DropIndex("dbo.Messages", new[] { "EmployeeId" });
            DropIndex("dbo.Engagements", new[] { "Employee_Id" });
            DropIndex("dbo.Documents", new[] { "Employee_Id" });
            DropTable("dbo.Messages");
            DropTable("dbo.Engagements");
            DropTable("dbo.Employees");
            DropTable("dbo.Documents");
        }
    }
}
