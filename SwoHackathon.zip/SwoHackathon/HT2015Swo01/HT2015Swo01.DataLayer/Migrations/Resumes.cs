﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HT2015Swo01.DataLayer.Migrations
{
    public static class Resumes
    {
        public static string Ryan = @"
Highly skilled at defining, organizing, and managing projects with business sponsors.
Deep technical expertise in Business Intelligence data modeling, ETL development, and front­end development.
Diverse experience across industries with roles in Architecture, Project Management, and Process Improvement.

Databases: Oracle, Microsoft SQL Server, DB2
Stored procedure/query development: PL/SQL, Transact­SQL
ETL Tools: IBM InfoSphere DataStage, SQL Server Integration Services (SSIS)
Reporting/Analytics Tools: SQL Server Analysis Services (SSAS), SQL Server Reporting Services (SSRS), Tableau, IBM
Cognos Suite, Oracle Balanced Scorecard
Enterprise Packages: Oracle E­Business Suite, Oracle Utilities ­ Meter Data Management
Led delivery on 8 engagements completing each on­time and at, or under, budget.
Led development of 18 proposals with 12 wins delivering $2.5M in increased revenue.
Collaborated with both business and IT customer representatives throughout the sales and delivery cycles";
        public static string Bennie = @"
10 years of professional experience to create leading edge applications for organizations in diverse industries .Certified technology developer and worked in all phases of the System Development Life Cycle, including planning, designing, programming source code, testing, configuration and release management.
Sun Certified Java Programmer (SCJP) & Sun Certified Web Component Developer (SCWCD)
Technical expertise includes Full lifecycle Object Oriented development utilizing a Rational Unified Process, which uses Use Case approach, Object Modeling, and Design.
Expertise in Object Oriented Analysis and Design (OOAD), UML/RUP and Java and J2EE Core Design Patterns, Use Cases, Sequence Diagram and Class Diagrams using UML with Rational Rose and Microsoft Visio
Development expertise in utilizing multiple languages like Java,J2EE IDE’s Net Beans and Eclipse.
Extensive experience in programming, deploying, configuring, fine-tuning and administering       ?Application Servers like IBM Web Sphere, BEA Web Logic, JBOSS & Web Server like Apache Tomcat
Worked in implementing applications using Strtus,Spring, and Hibernate Frameworks and soap web services
Worked in developing Ecommerce applications End to End through Hybris and Demandware Platform.
Expertise in J2EE technologies: EJB, JNDI, JMS, RMI and Web Application Development using EJB, Servlets, JSP, XML and JDBC.
Experience in n-tier Application Server Architecture, B2B / B2C Applications, Scalability, Security, Performance and Reusability
Experience in database programming using Oracle 9i/10g, Teradata, MS SQL Server 2000/2005, proficiency in developing SQL, PL/SQL in JDBC as well as client server environments.
Extensive experience in using HQL and PL/SQL to write Stored Procedures, Functions, Packages and Triggers.
Best Practice Mentoring – guiding development teams in use of best practice design strategies and design patterns in building mission-critical, enterprise applications
Extensively worked on Web Technologies Like XML, HTML,JavaScript, CSS, XSL, XSLT using Dreamweaver and FrontPage and ANT,  Shell Scripting were used for building and deploying applications on the Servers and also worked on various operating systems like Windows 2K/XP, MS-DOS, UNIX, Linux, Solaris.
Knowledge of Groovy & Grails Framework.";

        public static string Bob = @"
Experience - Work with mid-sized to multinational clients across multiple industries and geographies of Banking & Financial Services Institutions and Credit unions; Exceptional delivery management experience across SDLC of the project including ‘Long Running & Large Engagements’ and ‘High Frequency Release’ projects
Strengths: Versatile and capable of performing need-based roles like Business Analyst / Project Manager / Delivery Manager
Leadership: Exceptional collaborator in leading cross-functional and matrixed teams both nationally & internationally
Judgment: Reaches good, practical decisions based on factual information and sound logic to decide between competing courses of action. Accurately assesses the costs, benefits and risks associated with various alternative courses of action.
Decisiveness: Remains committed to a decision amidst controversy and doubt. Avoids analysis paralysis by sticking to deadlines and limiting analysis to necessary and productive efforts
Dependability: Exerts consistent effort to provide quality results that are focused on the bottom-line. In difficult situations, displays sensitivity and awareness of actions affecting customers and coworkers
Project Leadership: Natural leader who takes charge of complex projects from initial concept through all phases. Known for being cool and decisive during crises. Able to concurrently manage several ongoing projects
Business Analysis: Create and conduct requirement analysis, capture, functional work flow design, documenting business rules, performing gap & impact analysis, data mapping, requirement specification & functional design documents, use cases, Risk analysis
Skills: Excellent analytical, decision making, presentation, problem solving, communication & interpersonal skills with multitasking ability to sketch plans, prioritize work and manage complex responsibilities under aggressive timelines
Project Management
Project Co-ordination & Execution
Service Delivery & Assurance
Business Analysis
Business Process Management
Onshore / Offshore Co-ordination
Strategic Planning & Execution
Stakeholder Management
BFSI Domain Expert
Quality Control / Assurance
Solution Design / Architecture
Software Development Life Cycle (SDLC)
Requirement Gathering & Analysis
Business Requirements Document
Business Case Preparation
System Requirement Specification (SRS)
Use Case Diagrams (UML Modelling)
UAT Initiation & Support
Response to RFIs & RFPs
Gap Analysis
Feasibility Studies
AS-IS &TO-BE Processes
Change Management
Risk Assessment / Management
Capacity Management
Work Planning & Staffing
Resource Management ";


        public static string Brian = @"
She is a highly driven individual who enjoys the challenge of the problem at hand. She brings a Business Intelligence background with skills that pertain to Relational Database Modeling, Data Warehousing, Application Modeling, and Data Analysis. She has worked closely with the Microsoft Business Intelligence tools. She also has experience in strategic data management, data analysis, data visualization, and data warehousing solutions.  

She also excels in various soft skills such as being a fantastic team member who provides great input, professional communication skills, organized time management, detailed problem solving, great organization, ability to be highly adaptable, strong leadership qualities to guide a project, and an overall optimistic persona. She is always looking forward to learning more and the next challenge.
Programming Languages- C, C++, JAVA
Databases- Microsoft SQL Server, Oracle
ETL Tools- SQL Server Integration Services, Informatica
Data Warehousing Tools: SQL Server Analysis Services, Informatica
Visualization Tools- Tableau, QlikView
Data Modeling Tools- Erwin Data Modeler r9.5, MS Visio";


        public static string Carl = @"
Python,
Microsoft Windows 7, Vista, XP, 2000, ME,
Vertica, SAS/SQL, SAS/IML, SAS and R/Macros, SAS Enterprise Miner, SAS Text Miner, Tableau, Qlikview
Hadoop
WebSphere Application Server 6.x/7
Tomcat 5
Oracle, NoSQL
Crystal Reports 2008, SQL Server Reporting Services, InfoView, rePortal
Microsoft Visual SourceSafe, Team Foundation Server, StarTeam
Design of Experiment, Survey Questionnaire Design , Conjoint Analysis, Text Analytics/ Natural Language Processing, Data Visualization
HP Quality Center
Microsoft Office, Lotus Notes
Microsoft Office:  Word (expert), PowerPoint (expert), Excel (expert), Access, Outlook
Microsoft Visio, Microsoft Project, Database modeling
PL SQL Developer, SOAP UI
Sage MAS90/200, Sage MAS500, Sage BusinessWorks, SalesLogix CRM, Act!, Dynamics CRM
Linear and Non-linear Regression, (Binomial/ ordered or unordered Multinomial/Conditional/ Mixed Logit, Probit), Censored and Truncated Regression, Survival Analysis, Generalized Linear Mixed Model, Structural Equation Modeling, Latent Class Mixture, Segmentation – Clustering &
Classification, Random Forest, Neural Network, SVM, KNN, Marketing Mix Model, Scorecard Development, Fraud Detection, Choice Modeling , Market Basket Analysis, Customer Profiling & Life Time Value enumeration, Similarity Analysis & Recommendation, Panel Data Analysis, Time Series Forecasting
Sales and Distribution, Financial Services, Manufacturing, Professional Services, Pharmaceutical Research



Agile, Waterfall, Rational Unified Process (RUP)
RFP development and contract management, package selection, as-is/to-be process modeling and definition, executive meeting facilitation, requirements definition, estimating, schedule control, budget control ($3M+), management of cross-functional teams, global delivery management
Microsoft Office:  Word (expert), PowerPoint (expert), Excel (expert), Access, Outlook
Microsoft Visio (advanced)
Financial Services, Retail, Manufacturing, Healthcare, E-Commerce
PLM (Siemens TeamCenter, Enovia MatrixOne), CAD/3D-CAD, ERP (SAP),  Payroll (Kronos), POS (IBM, Toshiba), HP Quality Center
Application documentation";


        public static string Earnest = @"
Self-motivated problem solver with a passion for logic, coding and process improvement.  Quick, independent learner in pursuit of elegant ways to solve interesting challenges.
Oversee technical team responsible for Collections productivity and finance bad debt reporting. Maintain regular reporting commitments while curating and balancing existing workload to best utilize team strengths.  Respond to time-sensitive ad hoc requests in a dynamic environment with rapidly changing priorities.  Develop technical skills of both myself and team to increase process efficiency and overall capacity.  Successfully leveraged efficiencies gained through process improvement and automation to enhance and expand reporting output and team capacity.
Oversaw financial reporting and forecasting for Macy’s credit portfolios, through maintenance and ongoing improvement of forecasting models. Monthly presentation to senior management.  Managed team responsible for gathering and processing raw data, including development of data sources and process improvement.
Microsoft Office, VBA (experience in Excel and Access), VBS, Process Development & Improvement
Currently learning: SQL, Python, Java";


        public static string Eric = @"
Perform SOX Assessments for Fortune-500 clients in the telecom, financial services, retail, and grocery,
industries by analyzing communication interfaces, changes (people, process or systems), fraud
vulnerability, management override of controls, incentive structure, complex transactions, and degree of
judgment or human intervention involved in processing.
Coordinate efforts with control owners and internal audit services teams.
Conduct and document process and control walkthroughs.
Test business process and IT General Controls, entity-level controls, automated configurations, and key
reports.
Perform testing in conjunction with an internal audit function for Fortune-500 clients in the technology
industry.
Test IT general controls and review Internal Audit’s work around ITGC testing.
Evaluate the design and operating effectiveness of controls.
Business Analyst –
Problem Definition, Effort Estimation and Application Usability
Proposal Development, Solution evaluation and Recommendation
Architecture, Design and Detailing of Processes
Building & Maintaining Process Repository and participating in the Solution definition phase
Creating requirement specifications from business needs
Defining detailed design based on requirements
Significant exposure in Project lifecycle (Waterfall, AGILE / SCRUM), SDLC, Testing Methodology,
Change control/ Management, Client engagement management and Global sourcing delivery
model
Risk Assurance / IT Process Assurance – Controls Testing, Design and Operating effectivements review of IT
and Business Process controls
Web Development – .NET (C#), JavaScript, HTML, SharePoint Designer
Data Visualization – Tableau
Data Modeling – Relational Data Modeling, Conceptual, Logical and Physical Data Modeling
IBM Mainframes - COBOL, JCL, SPUFI (DB), LIMA ELIPS (Library Management), CA7 (Batch Job Scheduling)
MS Office – Excel Data Analysis tools, MS Visio
Statistical Computing – SAS, R
Other Skills – Analytical, Leadership, Communicative, Problem-Solving";


        public static string Herman = @"
Over 9+ years of overall IT experience with 7 years of experience on Extraction, Transformation and Loading (ETL) processes using IBM DataStage and QualityStage 8.7/8.1/ 7.x 
Extensive knowledge of Data Warehousing, business intelligence, ETL processing and Data Modeling
Experience in designing and implementing Data Mart applications, mainly transformation processes using ETL tool DataStage. 
Experience in using Information Analyzer for column analysis, primary key analysis and foreign key analysis
Designing and developing jobs using DataStage Designer DataStage Director and DataStage Administrator.
Developed jobs for SCD Type 2 using CDC stage, developed ABAP programs using datastage to extract data from SAP.
Extensively used DataStage Designer to design and develop server and parallel jobs to migrate data from transactional systems (Sybase, DB2UDB and flat files) into the Data Warehouse.
Expertise in Designing Parallel jobs using various stages like join, merge, lookup, remove duplicates, filter, dataset, lookup file set, modify, aggregator, Transformer.
Knowledge in Extraction, cleansing and modification of data from/to various Data sources like Oracle, XML files, Flat files and Comma Delimited files.
Extensively worked on DataStage Parallel Jobs using Various Stages like Join, Lookup, Change Capture, Filter, Funnel, Copy, Sort, File set, Sequential File, Data set, Oracle Enterprise, Merge, Aggregator, and Remove Duplicate Stages.
Experience working with Pentaho Data Integration Tool 
Practical Understanding of Data Modelling concepts like Star Schema Modeling, Snowflake Schema Modeling, Fact and Dimension tables. 
Experience in Data warehouse development life cycle and Design of Data marts 
Worked with Netezza, DB2, SQL, SQL*PLUS, Oracle PL/SQL, Stored Procedures, Table Partitions, SQL queries, and loading data into Data Warehouse/Data Marts.
Good knowledge of Database concepts such as indexing, views, schemas and other database objects in both Oracle and DB2 databases.
Conceptual knowledge of IDM, Pentaho Report Designer, Hyperion and Cognos. 
Detail oriented with good problem solving, organizational, analysis, highly motivated and adaptive with the ability to grasp things quickly.
Ability to work effectively and efficiently in a team and individually with excellent interpersonal, technical and communication skills.
";


        public static string Keenan = @"
BI and Visualization Tools: IBM SPSS, SAP BW, Tableau, MS Azure
Project Management: MS Project 2013, @RISK- Palisade Corporation
Testing Tools and IDE’s : HP Quality Center 10, HP ALM 11, HP QTP 11, qManage( LCS’s in-house ALM)
Databases and ERP : Oracle SQL, MySQL, SQL Server 2008, MS Access 2013, SAP ERP
O.S and S/W: Windows 8.1/7/XP, Mac OS X, MS Excel 2013 , MS Word 2013, MS PowerPoint 2013, MS Visual Studio
Programming : SAS, R, Java, C#,WPF, HTML 5.0
Worked extensively on all phases of software testing lifecycle including businessrequirement analysis, test planning,
test case preparation, test execution and defect triaging
Identified and automated scriptsforregression testing usingQuick Test Professional 11 which improved the
productivity by 70% and helped client in saving up to 5000 Pounds
Performed User Acceptance Testing while working closely with client team and also carried out the test data
preparation. Created total of 300 test data resources to be used for UAT
Carried out the end to end testing of a time critical project dealing with application and verification secondary
balance through online and IVRS before schedule and received excellent feedback from the onsite manager
Prepared and successfully executed close to 200 test scripts as a part of maintenance releases
Mentored team of new joiners to help smoothen their transition into the project and delivered presentations
to client on promising in-house technologies";

        public static string Leroy = @"
Data Enthusiast with about 3 years of experience in software development and Business consulting, enjoy data mining and
visualization to find insights in data.

Graduate Certificate in Data Analytics: Data Mining, Statistical Computing with SAS and R programming, Decision
Modeling, Data Visualization with Tableau, Business Intelligence, Data Modeling and Database Design
Monte Carlo Simulation: Conducted simulation studies on linear, logistic and probit regression
Regression analysis: Performed linear regression modeling, stratified analysis and variable selection methodologies
on simulated flight data
Credit scoring risk models: Performed CART and logistic regression analysis on real-time credit scoring and
bankruptcy data. Evaluated model performance using cross-validation techniques
Web Application for laptop store: Designed MVC 4.0 web application for a laptop store that includes CSS, validation,
authentication and authorization capabilities
Data Visualization using Tableau: Designed interactive dashboards to analyze flight and movie datasets

Programming: C, Java, C# ASP.NET MVC4, HTML, XML, Python
Statistical tools: R studio, SAS, simulation and optimization models using Excel
BI/Visualization: Tableau 8.3, Logi Info Studio BI platform, Advanced Excel
Databases and SQL: Oracle 11g, PL/SQL programming, MS SQL Server
ERP solutions: SAP ERP 6.0(FICO, MM, SD, PP), Oracle Applications E-Business Suite R11.5.x/R12";

        public static string Matt = @"
Matt Stover
She is a well-rounded IT professional with over 10 years of experience in web development, technical support,
business analysis and project management. She has worked with teams to develop and maintain web applications
and whether she is responding to support calls or gathering project requirements, she understands the
responsibilities of meeting her client’s needs.
Rebecca has played an essential role in all phases of the software development life cycle, including requirements
analysis & definition, solution architecture, solution design, implementation, integration, testing and maintenance.
She has excellent communication skills that allow her to serve as an effective liaison between the technical team
and the client.
Rebecca’s enthusiasm and dedication are the capstone to her success as an IT consultant.
Waterfall, Agile Processes as-is/to-be process modeling and definition, executive meeting facilitation, requirements definition, estimating, schedule control, management of crossfunctional teams Office Automation Microsoft Office: Word (expert), PowerPoint (expert), Excel (expert), Access, Outlook System Design Microsoft Visio (advanced), Microsoft Project, PlanView Document Management Documentum, FileNet, SharePoint, Ascent Capture 7.5, Virtual ReScan 4.1 Web Development HTML, PHP Quality Management HP Quality Center Reporting Tools Crystal Reports, SQL Server Reporting Services, InfoPath, DiCom Credit Quality Solution Databases SQL Server 2008, Oracle 10g & 11g MySQL, Microsoft Access, Informatica 7.1, Maestro Other Technical Application documentation Industries Medical Devices & Diagnostics, Financial Services, Healthcare, E-Commerce
";

        public static string Orlando = @"
is a Sogeti Consultant with a passion to work in IT and Business
environments. He has strong interpersonal, analytical, and problem
solving skills.
He takes great pride in delivering quality work and constantly strives to
learn new technologies and expand his skillset. He is currently learning
Angular.js and working on a User Experience assessment.
Daniel also excels in various soft skills such as being a fantastic team
member who provides great input, strong professional communication
skills, organized time management, detailed problem solving, great
organization, ability to be highly adaptable, strong leadership qualities to
guide a project, and an overall optimistic persona. He is always looking
forward to learning more and the next challenge.
Requirement Lifecycle Management (Sogeti’s proprietary methodology)
 Brown Paper Process
 Software Development Life Cycle (SDLC)
 Sogeti Agile Placemat (SCRUM Framework)
 Sogeti’s client typical Solution Development Process (SDP)
 System development methodologies and successful project management by implementing
Agile/ SCRUM
 Business communication
 Unit Testing
 Cloud computing
 Introduction to technologies like .NET 4.0, MVC, XML, SQL, SHAREPOINT and AZURE";

        public static string Pio = @"
is a motivated Manager Consultant with a background in Business Intelligence and Finance.  He has experience in manipulating various data sources to support Senior Management Decisions.  Demonstrated leadership abilities and teamwork skills as well as the ability to accomplish tasks under minimal direction and supervision.  Dave’s solid financial, technical, and business acumen helps him consistently overcome mission critical challenges for Fortune 500 organizations.  He maintains focus on achieving bottom-line results, while formulating and implementing advanced technology and business solutions to meet diverse needs. Dave is proficient at migrating IT/IS platforms across international boundaries, completing complex financial projects ahead of schedule and under budget, and maximizing operational performances through the use of BI tools.  He is also a proponent of the Kimball methodology of dimensional modelling and using the Agile approach to software development.
SQL Server, SSAS, SSIS, ETL, Performance Point, ZAP BI, Project Designer, Document Developer, Report Developer
SSRS, BI360, ZAP BI, SharePoint, Power BI, Power View, MicroStrategy
SQL, T-SQL, MDX
Microsoft Dynamics AX, Dynamics CRM, Dynamics NAV, JD Edwards, World and OneWorld, Oracle, PeopleSoft
Windows, Linux, Unix
Project Management, Business Analysis, Health and Life Insurance License
SQL, T-SQL, MDX, SSAS, ETL, SSIS, SSRS, Performance Point, Power Pivot, SharePoint, Microsoft Office Suite, SalesForce
";

        public static string Randy = @"
is a customer-focused consultant, proficient in SAP Business Objects (BO) tools including Universe Design Tool, Webi report writing, Web Intelligence Rich Client, Query As A Web Service (Qaaws) and Dashboards, using current versions of the software.  She has been working with the SAP BO tools since 2003.  She has held a position within an IT group for 7 years, supporting/designing and developing Financial universes and reports.  She has also done same type of work while supporting the sales organization of a major data warehousing company for 5 years.  Most recent project included a new Account and Opportunity universe that was designed to replace 2 other out-dated universes.   Also performed the sourcing updates for approximately 100 reports to the new universe.
Teradata SQL
Teradata Enterprise Data Warehouse, Microsoft Access, Progress Database
SAP BO Webi, SAP BO Web Intelligence Rich Client, SAP Dashboard, SAP Explorer, SAP Query As A Web Service, Teradata SQL Assistant
Microsoft Office
Microsoft Office:  Word, PowerPoint, Excel (expert), Access, Outlook
Erwin Data Modeler
Manufacturing
Agile, Waterfall, Rational Unified Process (RUP)
Requirements Definition and Documentation
Microsoft Office:  Word, PowerPoint, Excel (expert), Access, Outlook
Manufacturing
Linux (Teradata)
Application documentation";

        public static string Rico = @"
Expertise in using advanced data driven analytic techniques, predictive modelling, and state-of-the-art software to solve complex business and social problems.  Specializing in “R” graphical and procedural programming language, discrete event simulation, linear programming, and Microsoft Excel to solve problems associated with capacity constraints, factor utilization, causal relationships, forecasts, optimization, and economic impacts.
“R”, Excel, Forecasting Models (ARIMA, Exponential smoothing), Regression Analysis (OLS, Logistic, Poisson), Statistical Analysis (ANOVA, correlation, t-tests, descriptive statistics), Firm Economic Analysis (DuPont Model), Six Sigma (Capability, QC, sampling), Simulation (ProModel, Extend, GPSS, JaamSim, SLAM, AutoMod), ROE Analysis, Capital/Project Justification and Budgeting, Linear Programming, SAS, VBA, Equity Options Trading and Analysis, Supply/Demand Metrics for Futures, Principal Component and Factor Analysis, Classification, Cluster Analysis.
Consultancy using advanced data driven analytic techniques, predictive modelling, and state-of-the-art software to solve complex business and social problems. Specializing in “R” graphical and procedural programming language, discrete event simulation, linear programming, and Microsoft Excel to solve problems associated with capacity constraints, factor utilization, causal relationships, forecasts, optimization, and economic impacts.
First Business Planning Director hired to bring direction to organization awareness of service costs, productivity, and cash flow growth. Established organization’s industrial engineering team. Selected projects include: Labor Productivity: Implemented an Excel based flexible labor budgeting and performance measurement system resulting in savings of $400,000 annually (10 FTE’s). Physician Performance: Developed and implemented a monitoring report that measured a physicians’ patients’ average LOS (length of stay) by DRG category. Flagged excessive LOS by physician and resulted in LOS reductions of 10 % for 5% of the physicians. Customer Satisfaction: Conducted simulation of outpatient facility to measure capacity and patient waiting times under various labor scheduling scenarios. Resulted in a reduction of 20 minutes in service times for the average patient (from I hour originally) and an increase of throughput capacity of 30%.";

        public static string Stacey = @"
Agile, Waterfall, Lean Six Sigma 
Microsoft Office:  Word, PowerPoint, Excel, MS Visual Studio
Microsoft Visio
Business Analysis, Requirements Analysis, Business Consulting, Testing, Quality Assurance, Value Stream Mapping, Cost Benefit Analysis, Process Oriented, Stakeholder Analysis, Strategy Analysis, Business Cases, People and Change Management, Defect Management
Tableau, Rational Requirements Composer, HP Quality Center
SAP Business Objects, SQL Server, R, C, C++, Java, Dot Net, HTML 
Working as a Requirements Analyst in the People Soft application space on modules like Accounts Payable, General Ledger, eProcurement & ETL. Collaborated with teams from Accounting, Billing, and Purchasing & Procurement.
Facilitated sessions with both Business Leadership and Technical teams, translated both business and system needs into solution requirements and ensured business alignment.
Prepared and got the business signoff on System Requirements documents and Application Enhancement Specifications for both enhancements and large projects. Well-versed about the SDLC.
Worked on efforts at all scales- minor defect fix, enhancements and development of new applications.
Helped prepare RRC governance document along with the Requirements Analysts. Currently working to build the current state requirements in RRC for one of the Business Units.
Worked on UAT, batch job testing and interface file testing with the test lead of data services team.
";

        public static string Tim = @"
Tools and Utilities: Eclipse- IBM WMB V6.x, v7.0, Exposure to IBM WTX8.2, SOAP UI, MS Visio
Application Development: ESQL, SQL, XML, XSLT, XSD, XPath, HTML
Message Layers: WebSphere Messaging Queue Qv7.0x
Databases: DB2 v9.2, Oracle DB

IBM Certified Solution Developer WebSphere Message Broker V6.1, IBM Bangalore (2012)
IBM Certified Application Developer WebSphere Transformation Extender V8.2, IBM Bangalore (2012)
Won Performance Recognition award BE CSE 2007-2010
Ranked 1st in an Intra-College English Extempore competition 2010.
Ranked 1st in an Intra-College Technical Debate competition Technical Debate Competition 2008, 2009
Involved in Royal Bank of Canada, Fireman’s Fund Insurance Company and BNP Paribas Projects.
 Developed message flows in WMB for routing and filtering the incoming messages.
 Performed end-to-end unit testing and debugging of message flows in WMB.
 Coded the requirements in ESQL and JAVA based on the transaction performing Real time/ Batch in WMB-Input messages.
 Designed Conceptual and logical database applying ER Model and normalization concepts to it.
 Implemented entire project base databases using SQL.
 Coded SQL queries to look-up, modify, retrieve or delete records from DB2";

        public static string Tom = @"
Eclipse IDE, Design Patterns, JSP, XML
Jakob Nielsen’s 10 Usability Heuristics for User Interface Design
Ethnographic Interviews
Persona Creation and Refinement
Usability Testing
Prototyping
Stakeholder Interviews
Wrote applications for proofs of concept; enhanced existing product to meet customer requirements
Participated in the Agile software development process
Delivered bi-weekly progress reports to management
Engineered an Android application demonstrated by Lenovo at the Consumer Electronics Show
Performed software testing for a cloud-based product
Revised, tested, and audited software training";

        public static string Tommy = @"
6+ years of experience in IT industry especially in client/server business systems and Decision support Systems (DSS) /Enterprise Data warehouse (EDW) analysis, design, development, Testing and implementation.  
6 years of experience in populating and maintaining Data warehouses and DataMart’s using IBM Information Server v8.7, Ascential DataStage v7.5.x/6.x (Administrator, Director, Manager, Designer) – Server Edition, Enterprise Edition (Parallel Extender).
Involved in all the phases of the SDLC requirement gathering, design, development, Unit testing, UAT, Production roll-out, enhancements and Production support.
Worked with offshore team as co-coordinator with responsibilities such as providing solutions for the issues/troubles/technical difficulties that offshore team has on top of design documents, source to target mappings.
Expertise in Relational Database Modeling and Dimensional Modeling-Star schema, Snow-Flake schema, and hands on experience in data modeling tools Erwin / Microsoft Visio.
Experienced in troubleshooting DataStage jobs, enhancement of jobs and addressing production issues like performance tuning and enhancement.
Optimized DataStage jobs utilizing parallelism, partitioning and pipelining features of Parallel Extender.
Experience in designing Job Batches and Job Sequences for scheduling server and parallel jobs using DataStage Director, UNIX scripts.
Experience in migrating ETL code to upgraded version.
Experience in programming using SQL, PL/SQL, and UNIX Shell Scripting.
Extensive experience in Microsoft SQL Server 2005/2000, IBM DB2 UDB 8.0/7.0, Informix, Teradata, Oracle 10g/9i/8i., XML files and Message Queues.
Strong Experience in Unit testing and System testing of the DataStage jobs.
Experience in Scheduling the DataStage jobs using Control-M, Autosys.
Knowledge on designing and developing reports using BI/OLAP tools like Business Objects and Cognos.
Involved in Documentation of ETL process following the standard naming conventions used in DataStage. 
Excellent communication and interpersonal skills, teamwork, problem solving skills, flexible, self-direct and energetic person. 
Extensively worked co-coordinating with offshore team distributing the work, keep tracking development status and monitor day-to-day activities.
Installation, configuration, setup and Administration of DataStage Server.
Experience in DataStage Administrator to create/modify/delete projects, add DSN entries and cleanup projects and Implemented security among DataStage users and projects.
";

        public static string Travis = @"
Experienced	manager developing	and	running	software	and	hardware	projects	for	profitable	commercial	application.	Broadbased
experience	in	identifying	and	developing	skills	and	 talents	among	staff	and	colleagues	 to	ensure	achievement	of	all	
goals	and	 expectations.	Keen	ability	 to	work	with	 diverse	 groups	while	 communicating	 the	 big	 picture	 to	 identify	 gaps	 in	
knowledge	and	documentation.	Demonstrated	expertise	in	establishing	and	building	relationships	with	management,	staff,	
and	end	users. Recognized	for	the	ability	to	lead	professionals	and	staff	in	understanding	and	applying IS	and	IT	effectively.	
Providing	research	and	analysis	in	the	areas	of	information	management	and	application	of	technology.
Applications: MS	Office,	Visual	Studio,	NetBeans,	TextPad,	MySQL,	SQL	Server,	MS	Access,	SPSS,	Xcode,	Subversion,	Git
Languages:				VB/VB.NET,	PHP,	HTML,	jQuery,	CSS,	XML,	C++,	C#,	Java,	JavaScript,	COBOL,	Objective	C,	shell	scripting
OS: 									Windows	NT/2000/2003/XP/Vista/7/8,	Mac	OS	X/Linux/BSD Unix
Concepts:						Systems	Analysis	and	Design,	Project	Management,	Networking,	Database	Management
";

        public static string Wally = @"
Over 9+ years of IT experience in Designing, Developing and Testing of DataStage, Server and Parallel ETL jobs using IBM WebSphere DataStage, Data Analysis and Data Mapping.
Extensive Experience working with Ascential Data Stage, IBM Data Stage, IBM WebSphere Information Server.
Proficient and excellent in designing IBM Data Stage 9.1/8.7/8.0.1/8.1.0 Server and Parallel Jobs
Understanding of the QualityStage stages and MDM.
5 years of experience in BFSI domain.
4+ years of extensive experience as a technical lead and leading a team of 1- 5 developers.
2 + years of experience in on site-offshore co-ordination
Expertise in building Operational Data Store (ODS), Data Marts, and Decision Support Systems (DSS) using Multidimensional Model (Kimball and Inmon), Star and Snowflake schema design.
Experience in analyzing the data generated by the business process, defining the granularity, source to target mapping of the data elements.
Data Processing experience in designing and implementing Data Mart applications, mainly transformation processes using ETL tool DataStage (Ver8.0/7.5/7.0), designing and developing jobs using DataStage Designer, Data Stage Manager, DataStage Director and DataStage Debugger.
Efficient in incorporation of various data sources such as Oracle, MS SQL Server, DB2, Sybase, XML, Web services and Flat files into the staging area.
Expertise in importing metadata through Datastage manager/Designer.
Proven track record in addressing production issues like performance tuning and enhancement.
Efficient in all phases of the development lifecycle, coherent with Data Cleansing, Data Conversion, Performance Tuning and System Testing.
Excellent knowledge in creating and managing Conceptual, Logical and Physical Data Models using Erwin 4.1/7.2.
Strong in Data warehousing concepts, dimensional Star Schema and Snowflakes Schema methodologies.
Expert in unit testing, system integration testing, implementation, maintenance and performance tuning.
Excellent with SQL, T-SQL scripting.
Experience in UNIX command and Shell Scripting.
Excellent knowledge of operating systems Windows, UNIX, Macintosh, and databases including Oracle, SQL Server, and DB2.
Experience in implementing Quality Processes like ISO 9001:2000/Audits.
Detail oriented with good problem solving, organizational, analysis, highly motivated and adaptive with the ability to grasp things quickly.
Ability to work effectively and efficiently in a team and individually with excellent interpersonal, technical and communication skills.
";

    }
}
