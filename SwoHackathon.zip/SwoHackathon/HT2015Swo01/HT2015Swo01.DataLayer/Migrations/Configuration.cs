﻿using HT2015Swo01.DomainClasses;
using System.Collections.Generic;
using System.Data.Entity.Migrations;
using System.Linq;

namespace HT2015Swo01.DataLayer.Migrations
{
    public sealed class Configuration : DbMigrationsConfiguration<CounselorContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = true;
        }

        protected override void Seed(CounselorContext context)
        {
            if (context.Employees.Any()) return;
            EmployeeData.AddData(context);
        }
    }
}
