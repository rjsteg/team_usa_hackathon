﻿using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Migrations;
using HT2015Swo01.DomainClasses;
using System.IO;

namespace HT2015Swo01.DataLayer.Migrations
{
    public class DatabaseDevSeedingInitializier : DropCreateDatabaseAlways<CounselorContext>
    {
        protected override void Seed(CounselorContext context)
        {
            EmployeeData.AddData(context);
        }
    }
}

