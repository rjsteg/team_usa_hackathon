﻿using HT2015Swo01.DataLayer.Mappings;
using HT2015Swo01.DomainClasses;
using System.Data.Entity;

namespace HT2015Swo01.DataLayer
{
    public class CounselorContext : DbContext
    {
        public CounselorContext() : base("HT2015Swo01Database")
        {
        }

        public DbSet<Employee> Employees { get; set; }
        public DbSet<Document> Documents { get; set; }
        public DbSet<Message> Messages { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Configurations.Add(new EmployeeMapping());
            modelBuilder.Configurations.Add(new EngagementMapping());
            modelBuilder.Configurations.Add(new DocumentMapping());
            modelBuilder.Configurations.Add(new MessageMapping());
            base.OnModelCreating(modelBuilder);
        }
    }
}