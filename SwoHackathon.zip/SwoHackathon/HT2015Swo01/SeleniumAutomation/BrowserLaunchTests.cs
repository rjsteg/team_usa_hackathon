﻿using OpenQA.Selenium;

namespace SeleniumAutomation
{
    public class BrowserLaunchTests
    {
        public bool Go(string url)
        {
            Driver.Instance.Navigate().GoToUrl(url); 

            var divElement = Driver.Instance.Title;
            bool result = false;

            if (divElement != null)
            {
                result = divElement == "Home Page - Team SWO Application";
            }

            return result;
        }
    }
}
