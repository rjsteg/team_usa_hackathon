﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumAutomation;

namespace HT2015Swo01.Tests.UserInterface
{
    [TestClass]
    public class LaunchWebSite : BaseSeleniumTests
    {
        [TestMethod]
        public void LaunchBrowserLocal()
        {
            const string url = "http://localhost:50341/";
            var browserLaunchTests = new BrowserLaunchTests();
            Assert.IsTrue(browserLaunchTests.Go(url));
        }

        [TestMethod]
        [TestCategory("HTFunctionalDITTests")]
        public void LaunchBrowserDitEnvironment()
        {
            const string url = "http://sogetihtteamswo01dit.azurewebsites.net/";
            var browserLaunchTests = new BrowserLaunchTests();
            Assert.IsTrue(browserLaunchTests.Go(url));
        }
        [TestMethod]
        [TestCategory("HTFunctionalSITTests")]
        public void LaunchBrowserSitEnvironment()
        {
            const string url = "http://sogetihtteamswo01sit.azurewebsites.net/";
            var browserLaunchTests = new BrowserLaunchTests();
            Assert.IsTrue(browserLaunchTests.Go(url));
        }

    }
}
