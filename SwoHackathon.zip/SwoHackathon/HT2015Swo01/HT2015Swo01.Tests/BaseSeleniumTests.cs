﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumAutomation;

namespace HT2015Swo01.Tests
{
    [TestClass]
    public class BaseSeleniumTests
    {
        [TestInitialize]
        public void Init()
        {
            Driver.Initialize();
        }

        [TestCleanup]
        public void Cleanup()
        {
            Driver.Close();
        }
    }
}
