﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using HT2015Swo01.DataLayer.Migrations;
using System.Data.Entity;
using System.Linq;

namespace HT2015Swo01.DataLayer.Tests
{
    [TestClass]
    public class CreateAndPopulateDatabaseTests
    {
        //WARNING: When run this test will DELETE the databse the HT2015Swo01Database connection
        //         string is pointing to and create an empty database.
        //[Ignore]
        [TestMethod]
        [Ignore]
        public void CreateHT2015Swo01Database()
        {
            Database.SetInitializer(new DropCreateDatabaseAlways<CounselorContext>());
            using (var context = new CounselorContext())
            {
                Assert.AreEqual(0, context.Employees.Count());
            }
        }

        //WARNING: When run this test will DELETE the databse the HT2015Swo01Database connection
        //         string is pointing to and repopulate the database with the data in method
        //         DatabaseDevSeedingInitializier().
        //[Ignore]
        [TestMethod]
        [Ignore]
        public void CreateAndPopulateHT2015Swo01DatabaseWithDevData()
        {
            Database.SetInitializer(new DatabaseDevSeedingInitializier());
            using (var context = new CounselorContext())
            {
                Assert.AreEqual(4, context.Employees.Count());
            }
        }
    }
}
