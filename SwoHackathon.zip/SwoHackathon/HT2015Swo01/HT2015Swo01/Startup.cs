﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(HT2015Swo01.Startup))]
namespace HT2015Swo01
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
