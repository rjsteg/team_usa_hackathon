﻿using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;

namespace HT2015Swo01
{
    public class MvcApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            var migrator = new System.Data.Entity.Migrations.DbMigrator(new DataLayer.Migrations.Configuration());
            migrator.Update();
            migrator = new System.Data.Entity.Migrations.DbMigrator(new DataContexts.IdentityMigrations.Configuration());
            migrator.Update();

            AreaRegistration.RegisterAllAreas();
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);
        }
    }
}
