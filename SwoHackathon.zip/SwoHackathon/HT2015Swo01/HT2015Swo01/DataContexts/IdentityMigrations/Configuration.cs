﻿using HT2015Swo01.Models;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using System;
using System.Collections.Generic;
using System.Data.Entity.Migrations;
using System.Linq;
using System.Web;

namespace HT2015Swo01.DataContexts.IdentityMigrations
{
    internal sealed class Configuration : DbMigrationsConfiguration<IdentityDb>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;
        }

        protected override void Seed(IdentityDb context)
        {
            //  This method will be called after migrating to the latest version.

            if (!context.Roles.Any())
            {
                var roleStore = new RoleStore<IdentityRole>(context);
                var roleManager = new RoleManager<IdentityRole>(roleStore);
                var role = new IdentityRole { Name = "PracticeManager" };
                roleManager.Create(role);
                role = new IdentityRole { Name = "Counselor" };
                roleManager.Create(role);
                role = new IdentityRole { Name = "Counselee" };
                roleManager.Create(role);
            }
            if (!context.Users.Any())
            {
                var userStore = new UserStore<ApplicationUser>(context);
                var userManager = new UserManager<ApplicationUser>(userStore);
                var user = new ApplicationUser { UserName = "pm@us.sogeti.com", Email = "pm@us.sogeti.com" };
                userManager.Create(user, "password");
                userManager.AddToRole(user.Id, "PracticeManager");

                user = new ApplicationUser { UserName = "counselor@us.sogeti.com", Email = "counselor@us.sogeti.com" };
                userManager.Create(user, "password");
                userManager.AddToRole(user.Id, "Counselor");

                user = new ApplicationUser { UserName = "counselee@us.sogeti.com", Email = "counselee@us.sogeti.com" };
                userManager.Create(user, "password");
                userManager.AddToRole(user.Id, "Counselee");
            }
        }

    }
}