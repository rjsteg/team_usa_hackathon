﻿using HT2015Swo01.DataLayer;
using HT2015Swo01.DomainClasses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HT2015Swo01.Models
{
    public class MessageViewModel
    {
        public int Id { get; set; }
        public string sender { get; set; }
        public string recipient { get; set; }
        public string subject { get; set; }
        public string body { get; set; }



        public static implicit operator MessageViewModel(Message message)
        {
            using (var db = new CounselorContext())
            {
                var sender = db.Employees.Find(message.SenderId);
                var receipient = db.Employees.Find(message.RecepientId);
                return new MessageViewModel
                {
                    Id = message.Id,
                    sender = sender.FirstName + " " + sender.LastName,
                    recipient = receipient.FirstName + " " + receipient.LastName,
                    subject = "Test Message",
                    body = message.Body
                };
            }
        }
    }
}