﻿using HT2015Swo01.DomainClasses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HT2015Swo01.Models
{
    public class ConversationViewModel
    {
        public List<Message> Messages { get; set; }
        public Employee Employee { get; set; }
        public Employee Counselor { get; set; }

        public string NewMessage { get; set; }
    }
}