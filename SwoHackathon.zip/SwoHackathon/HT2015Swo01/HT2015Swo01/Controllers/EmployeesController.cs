﻿using HT2015Swo01.DataContexts;
using HT2015Swo01.DataLayer;
using HT2015Swo01.DomainClasses;
using HT2015Swo01.Models;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web.Mvc;

namespace HT2015Swo01.Controllers
{
    [Authorize]
    public class EmployeesController : Controller
    {
        private CounselorContext db = new CounselorContext();
        private IdentityDb identitydb = new IdentityDb();
        //private UserStore<ApplicationUser> userStore = new UserStore<ApplicationUser>(CurrentContext);

        // GET: Employees
        public ActionResult Index()
        {
            //Roles: User.IsInRole("PracticeManager")
            //  can assign counseolrs
            //  can view and edit all employees
            //  can view all documents and engagement records
            // can only view message in formation of counselees
            //Roles: User.IsInRole("Counselor")
            //  can view own employee record
            //  can add doucments 
            //  can view counselees employee, document, engagement and message information
            // can exchange messages with counselees
            // Neither role - then this is a counselee
            //  can view own employee record
            //  can add doucments 

            return View();
        }

        [ChildActionOnly]
        public ActionResult EmployeeList()
        {
            var userManager = new UserManager<ApplicationUser>(new UserStore<ApplicationUser>(identitydb));

            if (userManager.IsInRole(User.Identity.GetUserId(), "PracticeManager"))
            {
                return PartialView("_IndexPM", db.Employees.ToList());
            }
            else
            {
                return PartialView("_IndexCounselor", db.Employees.ToList());
            }
        }

        // GET: Employees/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Employee employee = db.Employees.Find(id);
            if (employee == null)
            {
                return HttpNotFound();
            }
            return View(employee);
        }

        // GET: Employees/Create
        [Authorize(Roles ="PracticeManager")]
        public ActionResult Create()
        {
            return View();
        }

        // POST: Employees/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "PracticeManager")]
        public ActionResult Create([Bind(Include = "Id,IdentityUserID,Email,FirstName,LastName,HireDate,ConsultantGrade,Practice,PracticeManager,CounselorId")] Employee employee)
        {
            if (ModelState.IsValid)
            {
                db.Employees.Add(employee);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(employee);
        }

        // GET: Employees/Edit/5
        [Authorize(Roles = "PracticeManager")]
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Employee employee = db.Employees.Find(id);
            if (employee == null)
            {
                return HttpNotFound();
            }
            return View(employee);
        }

        // POST: Employees/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "PracticeManager")]
        public ActionResult Edit([Bind(Include = "Id,IdentityUserID,Email,FirstName,LastName,HireDate,ConsultantGrade,Practice,PracticeManager,CounselorId")] Employee employee)
        {
            if (ModelState.IsValid)
            {
                db.Entry(employee).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(employee);
        }

        // GET: Employees/Delete/5
        [Authorize(Roles = "PracticeManager")]
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Employee employee = db.Employees.Find(id);
            if (employee == null)
            {
                return HttpNotFound();
            }
            return View(employee);
        }

        // POST: Employees/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "PracticeManager")]
        public ActionResult DeleteConfirmed(int id)
        {
            Employee employee = db.Employees.Find(id);
            db.Employees.Remove(employee);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
