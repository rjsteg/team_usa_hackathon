﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using HT2015Swo01.Models;
using HT2015Swo01.DataLayer;
using HT2015Swo01.DomainClasses;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using HT2015Swo01.DataContexts;

namespace HT2015Swo01.Controllers
{
    [Authorize]
    public class MessageController : Controller
    {
        private IdentityDb identitydb = new IdentityDb();

        public ActionResult Conversation()
        {
            var userManager = new UserManager<ApplicationUser>(new UserStore<ApplicationUser>(identitydb));
            var userid = User.Identity.GetUserId();
            var user = userManager.Users.Single(u => u.Id == userid);


            if (userManager.IsInRole(User.Identity.GetUserId(), "PracticeManager"))
            {
                TempData.Add("ErrorMessage", "Practice Manager's don't have counselors to message! :(");
                return RedirectToAction("List");
            }
            else
            {

                using (var db = new CounselorContext())
                {
                    var employee = db.Employees.Single(e => e.Email == user.Email);
                    var counselor = db.Employees.Single(e => e.Id == employee.CounselorId);
                    var messages = db.Messages.Where(e => e.EmployeeId == employee.Id)
                                              .Where(c => c.CounselorId == counselor.Id)
                                              .OrderBy(x => x.MessageSent)
                                              .ToList();

                    var vm = new ConversationViewModel { Messages = messages, Employee = employee, Counselor = counselor };

                    return View(vm);
                }
            }
        }

        [HttpPost]
        public ActionResult Conversation(ConversationViewModel viewModel, int receipientId, int senderId)
        {
            if (!string.IsNullOrWhiteSpace(viewModel.NewMessage))
            {
                using (var db = new CounselorContext())
                {

                    var message = new Message
                    {
                        Body = viewModel.NewMessage,
                        EmployeeId = senderId,
                        CounselorId = receipientId,
                        RecepientId = receipientId,
                        SenderId = senderId,
                        MessageSent = DateTime.Now,
                    };

                    db.Messages.Add(message);
                    db.SaveChanges();
                }
                return RedirectToAction("Conversation");
            }

            //TODO I forgot how to do this in MVC
            throw new Exception("you need to fill out the message");
        }

        // GET: Message
        public ActionResult Index()
        {
            return RedirectToActionPermanent("List");
        }

        public ActionResult List()
        {
            var messages = new List<Message>();
            var vm = new List<MessageViewModel>();

            var userManager = new UserManager<ApplicationUser>(new UserStore<ApplicationUser>(identitydb));
            var userid = User.Identity.GetUserId();
            var user = userManager.Users.Single(u => u.Id == userid);

            using (var db = new CounselorContext())
            {
                var employee = db.Employees.Single(e => e.Email == user.Email);

                ViewBag.Employee = employee.FirstName + " " + employee.LastName;

                messages = db.Messages.ToList();
                foreach (var message in messages)
                {
                    if (message.RecepientId == employee.Id || message.SenderId == employee.Id)
                    {
                        vm.Add(message);
                    }
                }
            }
            return View(vm);
        }

        // GET: Message/View/5
        public ActionResult View(int id)
        {
            var vm = new MessageViewModel();
            using (var db = new CounselorContext())
            {
                vm = db.Messages.Find(id);
            }

            return View(vm);
        }

        // GET: Message/Reply/5
        public ActionResult Reply(int id)
        {
            ViewBag.MessageId = id;
			
			var vm = new MessageViewModel();
            using (var db = new CounselorContext())
            {			
				var message = db.Messages.Find(id);

				ViewBag.SenderId = message.SenderId;
				ViewBag.ReceipientId = message.RecepientId;
				
				var sender = db.Employees.Find(message.SenderId);
                var receipient = db.Employees.Find(message.RecepientId);
				
                vm.recipient = receipient.FirstName + " " + receipient.LastName;
				vm.sender = sender.FirstName + " " + sender.LastName;
            }

            return View(vm);
        }

        // POST: Message/Reply/5
        [HttpPost]
        public ActionResult Reply(FormCollection collection)
        {
            try
            {
				using (var db = new CounselorContext())
                {
                    var message = new Message
                    {
                        Body = Request.Form["body"],
                        EmployeeId = Int32.Parse(Request.Form["senderId"]),
                        CounselorId = Int32.Parse(Request.Form["receipientId"]),
                        RecepientId = Int32.Parse(Request.Form["receipientId"]),
                        SenderId = Int32.Parse(Request.Form["senderId"]),
                        MessageSent = DateTime.Now,
                    };

                    db.Messages.Add(message);
                    db.SaveChanges();
                }
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }


        // GET: Message/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: Message/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
